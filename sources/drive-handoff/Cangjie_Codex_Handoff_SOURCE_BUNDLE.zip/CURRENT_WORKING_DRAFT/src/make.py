from pathlib import Path
from base64 import b64encode
import json,re
P=Path('/mnt/data/cangjie_build')
SRC=Path('/mnt/data/cangjie_zip_extract')
# Original chord shapes, string order 1 = high e ... 6 = low E. None means muted.
shapes={
'C':[0,1,0,2,3,None], 'C/Bb':[0,1,0,2,1,None], 'Am':[0,1,2,2,0,None],
'Abmaj7':[3,4,5,6,None,4],'G':[3,0,0,0,2,3],'Cmaj7':[0,0,0,2,3,None],
'Am7':[0,1,0,2,0,None],'Am7/G':[0,1,0,2,0,3],'Fmaj7':[0,1,2,3,3,None],
'F':[1,1,2,3,3,1], 'Gsus4':[3,1,0,0,3,3], 'G7':[1,0,0,0,2,3],
'Em7/B':[0,3,0,0,2,None],'Gm7':[3,3,3,3,5,3], 'C7':[0,1,3,2,3,None],
'C/E':[0,1,0,2,3,0],'Dm7':[1,1,2,0,None,None], 'D':[2,3,2,0,None,None],
'Bb':[1,3,3,3,1,None], 'Em7':[0,3,0,2,2,0], 'D7':[2,1,2,0,None,None],
'D/F#':[2,3,2,0,0,2], 'Fm7/C#':[1,1,1,3,4,None], 'Bm7':[2,3,2,4,2,None],
'A':[0,2,2,2,0,None], 'A/C#':[0,2,2,2,4,None]
}
trans={
'C':'G','C/Bb':'G/F','Am':'Em','Abmaj7':'Ebmaj7','G':'D','Cmaj7':'Gmaj7',
'Am7':'Em7','Am7/G':'Em7/D','Fmaj7':'Cmaj7','F':'C','Gsus4':'Dsus4','G7':'D7',
'Em7/B':'Bm7/F#','Gm7':'Dm7','C7':'G7','C/E':'G/B','Dm7':'Am7','D':'A','Bb':'F',
'Em7':'Bm7','D7':'A7','D/F#':'A/C#','Fm7/C#':'Cm7/G#','Bm7':'F#m7','A':'E','A/C#':'E/G#'
}
# New voicings for strum bars; these are easy/common playable chord shapes, NOT necessarily original inversion voicings.
voicings={
'G':[3,0,0,0,2,3], 'G/F':[3,0,0,0,None,1], 'Em':[0,0,0,2,2,0],
'Ebmaj7':[3,3,3,1,None,None], 'D':[2,3,2,0,None,None], 'Gmaj7':[2,0,0,0,2,3],
'Em7':[0,3,0,2,2,0], 'Em7/D':[0,3,0,0,2,None], 'Cmaj7':[0,0,0,2,3,None],
'C':[0,1,0,2,3,None], 'Dsus4':[3,3,2,0,None,None], 'D7':[2,1,2,0,None,None],
'Bm7/F#':[2,3,2,4,2,2], 'Dm7':[1,1,2,0,None,None], 'G7':[1,0,0,0,2,3],
'G/B':[3,0,0,0,2,None], 'Am7':[0,1,0,2,0,None], 'F':[1,1,2,3,3,1],
'A':[0,2,2,2,0,None], 'F#m7':[2,2,2,2,4,2], 'Cm7/G#':[3,4,3,5,3,4],
'Bm7':[2,3,2,4,2,None], 'A7':[0,2,0,2,0,None], 'A/C#':[0,2,2,2,4,None],
'E':[0,0,1,2,2,0],'E/G#':[0,0,1,2,2,4]
}
# Measure label, chord changes at fractional beats, texture and compact lyric segment.
# Source snapshots 7041-7056 show 1-67 bars, with repeat content overlap.
def row(i,ch,typ='pluck',lyr='',mel=''):
    changes=[]
    for frag in ch.split('|'):
        beat,name=frag.split(':') if ':' in frag else ('0',frag)
        assert name in shapes,(i,name)
        changes.append([float(beat),name])
    return {'i':i,'changes':changes,'type':typ,'lyr':lyr,'mel':mel}
rows=[
 row(1,'C','intro'),row(2,'C/Bb','intro'),row(3,'Am','intro'),row(4,'Abmaj7|2:G','intro'),
 row(5,'C','pluck','一颗葡萄有多甜美','0 5 5 5 5 4 3 4 5'),
 row(6,'Cmaj7','pluck','用尽了','0 5 6 7'),
 row(7,'Am7|2:Am7/G','pluck','所有的图腾','1 3 7 7 6 6 5'),
 row(8,'Fmaj7','pluck','和语言描写','5 6 1 1 1 2 2 3'),
 row(9,'C','pluck','想一个人有多想念','3 5 5 5 5 5 5 6 7 7'),
 row(10,'Cmaj7','pluck','那又是','7 5 5 0 5 6 7'),
 row(11,'Am7|2:Am7/G','pluck','文字失效瞬','1 3 3 3 3 2 2 1'),
 row(12,'F','pluck','间','2 1 1 1 — 0'),
 row(13,'C','pluck','结一个纪念的绳结','0 5 5 5 5 5 4 3 4 5'),
 row(14,'Cmaj7','pluck','记录你','5 — 0 5 6 7'),
 row(15,'Am7|2:Am7/G','pluck','离去后万语','1 3 7 7 6 6 5'),
 row(16,'Fmaj7','pluck','和千言瓦解','5 6 1 1 1 2 2 3'),
 row(17,'C','pluck','升起了慌张的狼烟','3 5 5 5 5 5 5 6 7 7'),
 row(18,'Cmaj7','pluck','我遗落','7 5 5 0 5 6 7'),
 row(19,'Am7|2:Am7/G','pluck','在最孤独史前','1 2 1 7 7 1 1 3'),
 row(20,'F','pluck','的荒野','3 — 0 3 4 3'),
 row(21,'Gsus4','pluck','（延续）','3 2 2 — —'),
 row(22,'G','hold','多','0 0 0 0 5'),
 row(23,'C|2:Em7/B','strum','遥远多纠结多','2 3 3 5 · 2 3 3 5'),
 row(24,'Am7|2:Gm7|3:C7','strum','想念多无法描写','2 3 3 5 · 5 3 2 1'),
 row(25,'F|2:C/E','strum','疼痛和疯癫','2 3 3 5 · 2 1 1'),
 row(26,'Dm7|2:G','strum','你都看不见想','4 3 3 1 · 6 5 5 5 5'),
 row(27,'C|2:Em7/B','strum','穿越想飞天想','2 3 3 5 · 2 3 3 5'),
 row(28,'Am7|2:Gm7|3:C7','strum','变成造字的仓颉','2 3 3 5 · 5 3 2 1'),
 row(29,'F|2:C/E','strum','写出','1 6 1 —'),
 row(30,'Dm7|2:G','strum','能让你快回来的诗篇','4 4 4 4 1 6 5 2 1 1'),
 row(31,'C','intro','（间奏）'),row(32,'C/Bb','intro'),row(33,'Am','interlude'),
 row(34,'G7|2:G7|3:F|3.5:G','strum','（间奏连接）'),
 row(35,'C','pluck','一只蝴蝶有多鲜艳','0 5 5 5 5 5 4 3 4 5'),
 row(36,'Bb','fill','能不能','5 — 0 5 6 7'),
 row(37,'C','fill','飞越过猜忌','1 3 7 7 6 6 5'),
 row(38,'Bb','fill','和冷漠世界','5 6 1 1 2 2 3'),
 row(39,'C','fill','给你的简讯和留言','3 5 5 5 5 5 5 6 7 7'),
 row(40,'Bb','fill','说不清','7 5 5 0 5 6 7'),
 row(41,'Am','solo','万分之一追悔','1 3 3 3 3 2 2 1'),
 row(42,'G','strum','（连接）','0 0 0 0 5'),
 row(43,'C|2:Em7/B','strum','遥远多纠结多','2 3 3 5 · 2 3 3 5'),
 row(44,'Am7|2:Gm7|3:C7','strum','想念多无法描写','2 3 3 5 · 5 3 2 1'),
 row(45,'F|2:C/E','strum','疼痛和疯癫','2 3 3 5 · 2 1 1'),
 row(46,'Dm7|2:G','strum','你都看不见想','4 3 3 1 · 6 5 5 5 5'),
 row(47,'C|2:Em7/B','strum','穿越想飞天想','2 3 3 5 · 2 3 3 5'),
 row(48,'Am7|2:Gm7|3:C7','strum','变成造字的仓颉','2 3 3 5 · 5 3 2 1'),
 row(49,'F|2:C/E','strum','写出','1 6 1 —'),
 row(50,'Dm7|2:G','strum','能让你快回来的诗','4 4 4 4 1 6 5 2 2 5'),
 row(51,'D|2:Fm7/C#','strum','要你需要你需要','2 3 3 5 · 2 3 3 5'),
 row(52,'Bm7|2:Am7|3:D7','strum','要你想逆转时间','2 3 3 5 · 5 3 2 1'),
 row(53,'G|2:D/F#','strum','回到最开始','2 3 3 5 · 2 1 1'),
 row(54,'Em7|2:A','strum','有你的世界想','4 3 3 1 · 6 5 5 5 5'),
 row(55,'Bm7|2:A/C#','strum','穿越想飞天想','2 3 3 5 · 2 3 3 5'),
 row(56,'D|2:Am7|3:D7','strum','变成造字的仓颉','2 3 3 5 · 5 3 2 1'),
 row(57,'G|2:D/F#','strum','写出','1 6 1 —'),
 row(58,'Em7|2:A','strum','让宇宙能重来的诗篇','4 4 4 4 1 6 5 2 1 1'),
 row(59,'D','strum','（延音）','1 — — —'),
 row(60,'C','strum','（过门）','0 0 0 0'),
 row(61,'Bm7','strum','啊','0 6 5 3'),
 row(62,'A','strum','啊','5 7 7 —'),
 row(63,'D','strum','oh','3 1 5 3 4'),
 row(64,'C','strum','oh','4 1 4 5 6 3 4 3'),
 row(65,'Bm7','strum','（延续）','3 1 1 1 1 5 1 2'),
 row(66,'A','strum','（尾声）','2 — — —'),
 row(67,'D','end','（结束）','0 0 0 0')
]
assert len(rows)==67 and all(r['i']==i+1 for i,r in enumerate(rows))
# pitch mapping for guitar (midi)
openm=[0,64,59,55,50,45,40]
# target selection favours chord voicing and low fret, tunes for standard G/A-shapes
outofrange=[]
def transform_note(s,f,ch,t):
    p=openm[s]+f-5  # target relative to capo, original C -> G fingering
    octaves=0
    while p<40:
        p+=12;octaves+=1
    candidates=[]
    for ns in range(1,7):
        nf=p-openm[ns]
        if not 0<=nf<=12:continue
        v=voicings[trans[ch]][ns-1]
        cost=nf*.45 + (0 if v==nf else 8) + (ns-1)*.09
        # prefer chord mapping if possible; avoid higher frets, preserve bass depth
        if ns==s:cost+=3
        if t in [0,2] and s>=5:cost+=abs(6-ns)*.25
        candidates.append((cost,ns,nf))
    if not candidates:raise ValueError(('not playable',s,f,ch,p))
    _,ns,nf=min(candidates)
    if octaves:outofrange.append((ch,s,f,ns,nf))
    return [ns,nf,octaves]
def chord_at(row,t):
    return next(ch for beat,ch in reversed(row['changes']) if beat<=t)
def ev(t,s,f,ch,k='p'):
    return {'t':t,'s':s,'f':f,'c':ch,'k':k}
def pluck_events(r):
    seq=[]
    def add(t,ss,override=None,k='p'):
        ch=chord_at(r,t)
        for s in ss:
            f=override.get(s) if override and s in override else shapes[ch][s-1]
            if f is None:continue
            seq.append(ev(t,s,f,ch,k if not (t==0 and s>=5) else 'b'))
    changes=r['changes'];bs=shapes[changes[0][1]]
    bass=5 if bs[4] is not None else 6 if bs[5] is not None else 4
    if changes[0][1] in ['F','Gsus4','G','G7','Bb','D','Am7/G']:
        bass=6 if bs[5] is not None else 5 if bs[4] is not None else 4
    if changes[0][1]=='Fmaj7':bass=4
    if changes[0][1]=='Am7':bass=5
    if changes[0][1]=='C/Bb':bass=5
    add(0,[bass,2,1])
    add(.5,[3]);add(1,[2,1]);add(1.5,[3]);
    if len(changes)>1:
        second=changes[1][1]
        sh=shapes[second]
        b=6 if sh[5] is not None else 5 if sh[4] is not None else 4
        add(2,[b,2,1])
    else:add(2,[2,1]);
    add(2.5,[3]);add(3,[2,1]);add(3.5,[3])
    return seq
# The intro m1-3 have 16ths notes at the end and actual observed top-line melody.
def intro_events(r):
    idx=r['i'];ch=r['changes'][0][1]
    if idx in (1,2,3,31,32,33):
        seq=[]
        bass=5 if idx!=33 else 5
        # first attack sometimes includes treble dyad (C only)
        if idx in (1,31):
            seq.extend([ev(0,5,3,ch,'b'),ev(0,2,1,ch),ev(0,1,0,ch,'m')])
        else:seq.extend([ev(0,5,shapes[ch][4],ch,'b'),ev(0,1,0,ch,'m')])
        sf=2 if ch=='Am' else 0
        for t in [.5,1.5,2.5]:seq.append(ev(t,3,sf,ch))
        for t in [1,2]:
            seq.append(ev(t,1,0,ch,'m'))
            if idx in (1,31):seq.append(ev(t,2,1,ch))
        for t,s,f in [(3,1,0),(3.25,1,1),(3.5,1,1),(3.75,2,3)]:seq.append(ev(t,s,f,ch,'m'))
        return sorted(seq,key=lambda x:x['t'])
    if idx==4:
        return [ev(0,6,4,'Abmaj7','b'),ev(0,3,5,'Abmaj7'),ev(0,2,4,'Abmaj7'),ev(0,1,3,'Abmaj7','m'),
                ev(.5,4,5,'Abmaj7'),ev(1,2,6,'Abmaj7','m'),ev(2,6,3,'G','b'),ev(2,2,1,'G','m'),ev(2.5,3,0,'G'),ev(3,2,3,'G','m')]
    return pluck_events(r)
# melodic fills after instrumental break, based on visible number marks.
def fill_events(r):
    if r['i']==35:return pluck_events(r)
    if r['i']==36:
        return [ev(0,5,1,'Bb','b'),ev(0,2,3,'Bb'),ev(1,1,0,'Bb','m'),ev(1.5,3,3,'Bb'),ev(2,4,3,'Bb'),ev(2.5,3,3,'Bb'),ev(3,4,3,'Bb'),ev(3.75,2,3,'Bb')]
    if r['i']==37:
        return [ev(0,5,3,'C','b'),ev(1,3,0,'C'),ev(2,2,1,'C','m'),ev(3,3,2,'C','m'),ev(3.5,3,2,'C','m')]
    if r['i']==38:
        return [ev(0,5,1,'Bb','b'),ev(0,1,0,'Bb','m'),ev(1,4,3,'Bb'),ev(2,3,3,'Bb'),ev(2.5,3,3,'Bb'),ev(3.5,3,5,'Bb','m')]
    if r['i']==39:
        return [ev(0,5,3,'C','b'),ev(1,3,0,'C'),ev(2,2,1,'C','m'),ev(2.5,3,0,'C'),ev(3,3,2,'C','m'),ev(3.5,3,2,'C','m')]
    if r['i']==40:
        return [ev(0,5,1,'Bb','b'),ev(0,1,0,'Bb','m'),ev(.5,3,3,'Bb'),ev(1,4,3,'Bb'),ev(2,3,3,'Bb'),ev(2.5,1,0,'Bb','m'),ev(3,3,3,'Bb'),ev(3.5,2,1,'Bb','m')]
    return pluck_events(r)
def solo_events(r):
    return [ev(0,5,0,'Am','b'),ev(0,1,3,'Am','m'),ev(.25,1,0,'Am','m'),ev(.5,2,1,'Am','m'),ev(.75,3,2,'Am','m'),ev(1,2,3,'Am','m'),ev(1.25,2,3,'Am','m'),ev(1.5,2,3,'Am','m'),ev(1.75,2,3,'Am','m'),ev(2,2,0,'Am','m'),ev(2.25,2,0,'Am','m'),ev(2.5,2,1,'Am','m'),ev(2.75,2,0,'Am','m'),ev(3,3,2,'Am','m'),ev(3.5,2,3,'Am','m')]
# Strumming tokens: duration and up/down articulation consistent with screen arrows.
strum_pattern=[(0,'d'),(.75,'d'),(1.25,'d'),(1.5,'u'),(2,'u'),(2.5,'d'),(3,'u'),(3.5,'d'),(3.75,'u')]
# all bars get true score events. No placeholder bars, no extraneous screenshot pages in print.
for r in rows:
    if r['type']=='intro':notes=intro_events(r)
    elif r['type']=='pluck':notes=pluck_events(r)
    elif r['type']=='fill':notes=fill_events(r)
    elif r['type']=='solo':notes=solo_events(r)
    else:notes=[]
    if r['type']=='hold':
        notes=[ev(0,6,3,'G','b'),ev(3,2,3,'G','m')]
    if r['type']=='end':
        notes=[ev(0,4,0,'D','b'),ev(0,3,2,'D'),ev(0,2,3,'D'),ev(0,1,2,'D','m')]
    r['notes']=notes
    r['strums']=[]
    if r['type']=='strum':
        # chord changes at their actual position, follow a normal 4-beat 8th-note up/down feel
        r['strums']=[{'t':t,'dir':direction,'c':chord_at(r,t)} for t,direction in strum_pattern]
    r['targetChanges']=[[t,trans[ch]] for t,ch in r['changes']]
    r['targetNotes']=[]
    for n in notes:
        ns,nf,up=transform_note(n['s'],n['f'],n['c'],n['t'])
        r['targetNotes'].append({**n,'s':ns,'f':nf,'oct':up,'c':trans[n['c']]})
    r['targetStrums']=[{**s,'c':trans[s['c']]} for s in r['strums']]

print('bars',len(rows),'source notes',sum(len(x['notes']) for x in rows),'octaves shifted',len(outofrange))
from collections import Counter
print('chords',Counter(ch for r in rows for t,ch in r['changes']))
print('octaves examples',outofrange[:25])
(P/'score.json').write_text(json.dumps({'rows':rows,'shapes':shapes,'voicings':voicings,'trans':trans},ensure_ascii=False),encoding='utf-8')
