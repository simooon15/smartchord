(() => {
'use strict';
const scoreData=JSON.parse(document.getElementById('score-data').textContent);
const rows=scoreData.rows,shapes=scoreData.shapes,voicings=scoreData.voicings;
const $=id=>document.getElementById(id),NS='http://www.w3.org/2000/svg';
const openMidi=[0,64,59,55,50,45,40];
const sections=[
 {name:'整首',start:1,end:67},
 {name:'前奏',start:1,end:4},
 {name:'主歌（一）',start:5,end:22},
 {name:'副歌（一）',start:23,end:30},
 {name:'间奏与主歌（二）',start:31,end:42},
 {name:'副歌（二）',start:43,end:50},
 {name:'升调副歌',start:51,end:58},
 {name:'尾声',start:59,end:67}
];
let currentMode='target',bpm=76,playing=false,loop=false,follow=true,clickTrack=false;
let ac=null,soundMaster=null,events=[],nextIdx=0,anchor=0,startContextTime=0,raf=0,beat=0;
let noteGfx=[],viewMeasure=1,sectionIndex=0,lastScroll=0;
const keyLabel=n=>n<51?'1 = G（实际 A 调）':'1 = A（实际 B 调）';
const modalData=scoreData.sourceImages;
const e=(tag,attr={},text)=>{const n=document.createElementNS(NS,tag);Object.entries(attr).forEach(([k,v])=>n.setAttribute(k,String(v)));if(text!==undefined)n.textContent=text;return n};
const text=(svg,x,y,str,cls,extra={})=>svg.appendChild(e('text',{x,y,class:cls,...extra},str));
const aString=(s)=>['','e','B','G','D','A','E'][s];
function shapeList(){
 const all=new Map();for(const r of rows){for(const [t,ch] of (currentMode==='target'?r.targetChanges:r.changes))all.set(ch,1)}
 return [...all.keys()];
}
function viewRows(){return rows.map(r=>({base:r,changes:currentMode==='target'?r.targetChanges:r.changes,notes:currentMode==='target'?r.targetNotes:r.notes,strums:currentMode==='target'?r.targetStrums:r.strums}));}
function chordAt(changes,t){let result=changes[0][1];for(const [beat,ch] of changes){if(beat>t)break;result=ch}return result;}
function svgSystem(barList){
 const svg=e('svg',{viewBox:'0 0 1090 217',class:'staff-system',role:'img','aria-label':`第 ${barList[0].base.i} 到 ${barList.at(-1).base.i} 小节`});
 const eachBarWidth=260,startX=31;
 for(let k=0;k<4;k++){
  let x=startX+k*eachBarWidth;
  if(k>=barList.length)continue;
  let r=barList[k],bar=r.base;
  svg.appendChild(e('rect',{x:x-3,y:4,width:259,height:210,class:'bar-hit-area','data-measure':bar.i,fill:'transparent'}));
  if(k===0){for(let s=1;s<=6;s++)text(svg,7,61+(s-1)*15+4,aString(s),'string-label');}
  text(svg,x,18,String(bar.i),'bar-number');
  if(bar.i===1||bar.i===51)text(svg,x+191,15,keyLabel(bar.i),'bar-key-note',{'text-anchor':'end'});
  r.changes.forEach(([t,ch])=>text(svg,x+15+t*57,43,ch,'chord-label'));
  for(let s=1;s<=6;s++)svg.appendChild(e('line',{x1:x+1,x2:x+253,y1:61+(s-1)*15,y2:61+(s-1)*15,class:'string-line'}));
  svg.appendChild(e('line',{x1:x+1,x2:x+1,y1:61,y2:136,class:'barline'}));
  svg.appendChild(e('line',{x1:x+253,x2:x+253,y1:61,y2:136,class:'barline'}));
  if(bar.i===67){svg.appendChild(e('line',{x1:x+247,x2:x+247,y1:61,y2:136,class:'heavy-barline'}));}
  const xy=t=>x+16+57*t;
  if(r.strums.length){
   for(const st of r.strums){
    let xpos=xy(st.t);
    text(svg,xpos,59,st.dir==='d'?'↓':'↑','strum-direction',{'text-anchor':'middle'});
    // a slanted rhythmic slash on the 3rd and 4th strings
    svg.appendChild(e('path',{d:`M ${xpos-6} 99 L ${xpos+6} 87`,class:'strum-slash'}));
    svg.appendChild(e('line',{x1:xpos,x2:xpos,y1:144,y2:165,class:'rhythm-stem'}));
    let dot=e('rect',{x:xpos-9,y:45,width:18,height:67,fill:'transparent',class:'sound-target'});
    dot.addEventListener('click',evt=>{evt.stopPropagation();previewChord(st.c,st.dir)});
    svg.appendChild(dot);
   }
  } else {
   const times=[...new Set(r.notes.map(n=>n.t))].sort((a,b)=>a-b);
   if(bar.type==='hold')times.push(1,2);
   for(let j=0;j<times.length;j++){
    const t=times[j],xpos=xy(t);
    svg.appendChild(e('line',{x1:xpos,x2:xpos,y1:144,y2:163,class:'rhythm-stem'}));
   }
   // draw eighth beams in groups of two except the intro's 16th-note run
   const groups=[[0,.5],[1,1.5],[2,2.5],[3,3.5]];
   if(['intro','interlude'].includes(bar.type))groups[3]=[3,3.25,3.5,3.75];
   groups.forEach(g=>{
    if(g.every(t=>times.includes(t))){svg.appendChild(e('line',{x1:xy(g[0]),x2:xy(g.at(-1)),y1:163,y2:163,class:'rhythm-beam'}));
      if(g.length>2)svg.appendChild(e('line',{x1:xy(g[0]),x2:xy(g.at(-1)),y1:167,y2:167,class:'rhythm-beam'}))}
   });
   for(const n of r.notes){
    let ypos=61+(n.s-1)*15,xpos=xy(n.t);
    let fret=e('text',{x:xpos,y:ypos,class:'fret'+(n.k==='m'?' fret-lead':'')+(n.oct?' fret-oct':''),'text-anchor':'middle','dominant-baseline':'middle',role:'button',tabindex:'0','aria-label':`${aString(n.s)}弦${n.f}品`},String(n.f));
    fret.addEventListener('click',evt=>{evt.stopPropagation();previewNote(n)});
    fret.addEventListener('keydown',evt=>{if(evt.key==='Enter'||evt.key===' '){evt.preventDefault();previewNote(n)}});
    svg.appendChild(fret);
   }
  }
  text(svg,x+16,182,bar.mel||'','jianpu-line');
  text(svg,x+16,203,bar.lyr||'','lyric-line');
  let active=e('rect',{x:x+1,y:59,width:252,height:78,class:'bar-current',fill:'transparent','data-active':bar.i});svg.appendChild(active);
  const cursor=e('line',{x1:xy(0),x2:xy(0),y1:48,y2:168,class:'cursor','data-cursor':bar.i});svg.appendChild(cursor);
  svg.addEventListener('click',evt=>{if(evt.target.closest('.sound-target')||evt.target.classList.contains('fret'))return;let point=svg.createSVGPoint();point.x=evt.clientX;point.y=evt.clientY;let transformed=point.matrixTransform(svg.getScreenCTM().inverse());let local=Math.max(0,Math.min(3.999,(transformed.x-x-16)/57));const b=Number(bar.i-1)*4+local;if(evt.target.closest('[data-measure]')?.getAttribute('data-measure')===String(bar.i))seek(b);});
 }
 return svg;
}
function renderScore(){
 const scored=viewRows(),output=$('score');output.replaceChildren();noteGfx=[];
 const groupings=[['前奏',1,4],['主歌',5,22],['副歌',23,30],['间奏 / 第二段',31,42],['副歌重复',43,50],['升调副歌',51,58],['尾声',59,67]];
 for(const [label,first,last] of groupings){
  const group=document.createElement('section');group.className='section-group';group.id='section-'+first;
  const heading=document.createElement('div');heading.className='section-heading';heading.innerHTML=`<span>${label}</span><small>${first}–${last} 小节 · ${keyLabel(first)}</small>`;group.appendChild(heading);
  const list=scored.filter(r=>r.base.i>=first&&r.base.i<=last);
  for(let i=0;i<list.length;i+=4){const system=document.createElement('div');system.className='system-wrap';system.appendChild(svgSystem(list.slice(i,i+4)));group.appendChild(system)}
  output.appendChild(group);
 }
 $('visible-count').textContent='全曲 · 67 小节';
 highlight(beat,true);
}
function highlight(b,quiet=false){
 beat=Math.max(0,Math.min(268,b));
 const bar=Math.min(67,Math.floor(beat/4)+1),local=beat%4;
 const rel=(beat/268*100).toFixed(2)+'%';$('progressfill').style.width=rel;
 $('played').textContent=format(beat*60/bpm);$('duration').textContent=format(268*60/bpm);
 $('playing-bar').textContent=`第 ${bar} / 67 小节`;
 if(!quiet){
  const active=document.querySelector('.bar-current.active');if(active)active.classList.remove('active');
  const newActive=document.querySelector(`[data-active="${bar}"]`);if(newActive)newActive.classList.add('active');
  const cursorOld=document.querySelector('.cursor.visible');if(cursorOld)cursorOld.classList.remove('visible');
  const cursor=document.querySelector(`[data-cursor="${bar}"]`);
  if(cursor){cursor.classList.add('visible');const raw=cursor.getAttribute('x1');const old=Number(raw);const barStart=old-Math.floor((old-31)/260)*0; /* kept below by viewBox relative positions */
   const marker=document.querySelector(`[data-active="${bar}"]`),x=marker?Number(marker.getAttribute('x')):31;
   const target=x+15+local*57;cursor.setAttribute('x1',target);cursor.setAttribute('x2',target);
  }
 }
 if(follow&&playing&&bar!==viewMeasure){viewMeasure=bar;const selected=document.querySelector(`[data-active="${bar}"]`);if(selected){const area=selected.closest('.system-wrap');const r=area.getBoundingClientRect();if(r.bottom>window.innerHeight-25||r.top<130){area.scrollIntoView({behavior:'smooth',block:'center'})}}}
}
function format(secs){const s=Math.max(0,Math.floor(secs));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
function getAudio(){if(!ac){const A=window.AudioContext||window.webkitAudioContext;if(!A)throw Error('当前浏览器不支持播放，请用 Chrome 或 Safari。');ac=new A();soundMaster=ac.createDynamicsCompressor();soundMaster.threshold.value=-20;soundMaster.knee.value=22;soundMaster.ratio.value=3;soundMaster.attack.value=.004;soundMaster.release.value=.16;soundMaster.connect(ac.destination)}if(ac.state==='suspended')ac.resume();return ac}
function noteFreq(n){let midi=openMidi[n.s]+n.f+(currentMode==='target'?2:0);return 440*Math.pow(2,(midi-69)/12)}
function pluck(t,freq,level=.09,len=1.1){const c=getAudio();let g=c.createGain(),f=c.createBiquadFilter(),o=c.createOscillator(),h=c.createOscillator(),hg=c.createGain();o.type='triangle';h.type='sine';o.frequency.value=freq;h.frequency.value=2*freq;f.type='lowpass';f.frequency.setValueAtTime(3000,t);f.frequency.exponentialRampToValueAtTime(750,t+Math.min(len,.7));g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(level,t+.007);g.gain.exponentialRampToValueAtTime(.0001,t+len);hg.gain.value=.13;o.connect(f);h.connect(hg);hg.connect(f);f.connect(g);g.connect(soundMaster);o.start(t);h.start(t);o.stop(t+len+.02);h.stop(t+len+.02)}
function click(t,primary=false){const c=getAudio(),o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.value=primary?1050:730;g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.065,t+.005);g.gain.exponentialRampToValueAtTime(.0001,t+.06);o.connect(g);g.connect(soundMaster);o.start(t);o.stop(t+.07)}
function chordNotes(name){const map=currentMode==='target'?voicings:shapes;const shape=map[name];if(!shape)return[];let notes=[];for(let s=6;s>=1;s--){if(shape[s-1]!==null&&shape[s-1]!==undefined)notes.push({s,f:shape[s-1]})}return notes}
function audioStrum(t,c,dir,vol=.058){let notes=chordNotes(c);if(dir==='u')notes.reverse();const common=Math.max(.024,vol/Math.pow(notes.length/4,.7));notes.forEach((n,j)=>pluck(t+j*.014,noteFreq(n),common,.75))}
function previewChord(c,dir){try{audioStrum(getAudio().currentTime+.04,c,dir,.16)}catch(e){err(e)}}
function previewNote(n){try{pluck(getAudio().currentTime+.02,noteFreq(n),.20,.92)}catch(e){err(e)}}
function getRange(){const s=sections[sectionIndex];return [(s.start-1)*4,s.end*4]}
function allEvents(){const arr=[];let [min,max]=getRange();for(const r of viewRows()){
  const pos=(r.base.i-1)*4;if(pos<min||pos>=max)continue;
  r.notes.forEach(n=>arr.push({b:pos+n.t,note:n}));
  r.strums.forEach(s=>arr.push({b:pos+s.t,strum:s}));
 }
 if(clickTrack)for(let b=min;b<max;b++)arr.push({b,click:b%4===0?'first':'other'});
 return arr.sort((a,b)=>a.b-b.b);
}
function currentBeat(){return playing?Math.max(anchor,anchor+(ac.currentTime-startContextTime)*bpm/60):beat}
function setPlayLabel(){$('play').textContent=playing?'Ⅱ 暂停':'▶ 播放'}
function start(at=beat){
 try{getAudio();cancelAnimationFrame(raf);let [lo,hi]=getRange();if(at>=hi-.001||at<lo)at=lo;
  anchor=at;beat=at;startContextTime=ac.currentTime+.07;events=allEvents();nextIdx=events.findIndex(e=>e.b>=at-.00001);if(nextIdx<0)nextIdx=events.length;playing=true;setPlayLabel();err(null);tick()}
 catch(e){err(e)}
}
function stop(){if(!playing)return;beat=Math.min(268,currentBeat());playing=false;cancelAnimationFrame(raf);setPlayLabel();highlight(beat)}
function seek(next){const [lo,hi]=getRange();const t=Math.max(lo,Math.min(hi-.0001,next));if(playing)start(t);else{beat=t;highlight(t)}}
function tick(){if(!playing)return;const c=ac.currentTime;
 while(nextIdx<events.length){let ev=events[nextIdx],at=startContextTime+(ev.b-anchor)*60/bpm;if(at>c+.17)break;nextIdx++;if(at<c-.025)continue;
  if(ev.click){click(at,ev.click==='first')}else if(ev.note){pluck(at,noteFreq(ev.note),ev.note.k==='m'?.13:ev.note.k==='b'?.125:.095,.9)}else if(ev.strum){audioStrum(at,ev.strum.c,ev.strum.dir)}
 }
 const now=currentBeat(),[lo,hi]=getRange();
 if(now>=hi){playing=false;cancelAnimationFrame(raf);beat=hi;highlight(beat);setPlayLabel();if(loop)start(lo);return;}
 highlight(now);raf=requestAnimationFrame(tick)
}
function err(e){$('error').textContent=e?(e.message||String(e)):''}
function mode(which){if(playing)stop();currentMode=which;renderScore();for(const key of ['target','original'])$('mode-'+key).classList.toggle('selected',which===key);$('current-key').textContent=which==='target'?'G 指法 · 变调夹 2 品':'原 C 调 · 不夹变调夹';}
$('play').addEventListener('click',()=>playing?stop():start(beat));
$('restart').addEventListener('click',()=>{if(playing)stop();start(getRange()[0])});
$('bpm-input').addEventListener('input',e=>{const old=currentBeat();if(playing)stop();bpm=Number(e.target.value);$('bpm-out').textContent=bpm+' BPM';seek(Math.min(getRange()[1]-.001,old));if($('autoresume').checked)start(beat)});
$('section-input').addEventListener('change',e=>{if(playing)stop();sectionIndex=Number(e.target.value);beat=getRange()[0];highlight(beat);const row=Math.floor(beat/4)+1;document.querySelector(`[data-active="${row}"]`)?.closest('.system-wrap')?.scrollIntoView({behavior:'smooth',block:'center'})});
$('loop').addEventListener('change',e=>loop=e.target.checked);$('follow').addEventListener('change',e=>follow=e.target.checked);
$('click').addEventListener('change',e=>{clickTrack=e.target.checked;if(playing)start(currentBeat())});
$('mode-target').addEventListener('click',()=>mode('target'));
$('mode-original').addEventListener('click',()=>mode('original'));
$('seekbar').addEventListener('click',e=>{const rect=e.currentTarget.getBoundingClientRect(),p=(e.clientX-rect.left)/rect.width;const b=Math.floor(Math.max(0,Math.min(.9999,p))*268);seek(b)});
$('print').addEventListener('click',()=>{if(playing)stop();if(currentMode!=='target')mode('target');window.print()});
for(let i=0;i<sections.length;i++){const o=document.createElement('option');o.value=i;o.textContent=sections[i].name;$('section-input').appendChild(o)}
// Available original screenshots are embedded in this SAME html, loaded only on request.
$('show-sources').addEventListener('click',()=>{
 const gallery=$('source-gallery');gallery.hidden=!gallery.hidden;if(gallery.hidden||gallery.dataset.loaded)return;gallery.dataset.loaded='true';
 modalData.forEach((item,i)=>{const fig=document.createElement('figure');fig.className='source-image';const img=document.createElement('img');img.loading='lazy';img.alt=`原谱截图 ${i+1}`;img.src=item.data;fig.appendChild(img);const cap=document.createElement('figcaption');cap.textContent='原谱 · '+item.name;fig.appendChild(cap);gallery.appendChild(fig)})
});
$('bpm-out').textContent=bpm+' BPM';setPlayLabel();renderScore();highlight(0);
})();
