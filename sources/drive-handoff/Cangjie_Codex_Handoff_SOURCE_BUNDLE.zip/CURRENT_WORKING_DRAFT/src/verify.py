from playwright.sync_api import sync_playwright
from pathlib import Path
f=Path('/mnt/data/仓颉_完整交互六线谱_G指法_Capo2.html')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--allow-file-access-from-files'])
 page=browser.new_page(viewport={'width':1280,'height':950},device_scale_factor=1)
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(f.read_text(encoding='utf-8'),wait_until='load',timeout=120000)
 print('title',page.title())
 print('errors',errors[:10])
 print('bar nodes',page.locator('.bar-current').count())
 print('systems',page.locator('.staff-system').count())
 print('sections',page.locator('.section-heading').count())
 print('chords',page.locator('.chord-label').count())
 print('notes',page.locator('.fret').count())
 print('strums',page.locator('.strum-direction').count())
 print('button',page.locator('#play').inner_text())
 page.screenshot(path='/mnt/data/cangjie_build/screen.png',full_page=False)
 page.get_by_role('button',name='原 C 调对照').click()
 print('orig key',page.locator('#current-key').inner_text(),'orig notes',page.locator('.fret').count())
 page.get_by_role('button',name='G 指法 · Capo 2').click()
 print('new key',page.locator('#current-key').inner_text())
 page.locator('#bpm-input').fill('88')
 print('bpm',page.locator('#bpm-out').inner_text())
 page.locator('#section-input').select_option('5')
 print('section',page.locator('#playing-bar').inner_text())
 page.locator('#section-input').select_option('0')
 # print to pdf directly from browser, native CSS print
 pdf_path='/mnt/data/cangjie_build/proof.pdf'
 page.pdf(path=pdf_path,format='A4',print_background=True,prefer_css_page_size=True,margin={'top':'0px','bottom':'0px','left':'0px','right':'0px'})
 print('pdf size',Path(pdf_path).stat().st_size)
 browser.close()
